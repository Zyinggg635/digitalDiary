package com.system.fop;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class EditController {
    @FXML
    private TextArea contentField;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Slider moodSlider;
    @FXML
    private TextField titleField;
    @FXML
    private VBox imageArea;
    @FXML
    private Text imagePath;
    @FXML
    private Button imageUpload;
    private String filePath;
    private String username;
    private String currentEntry;

    public void setUsername(String username) {
        this.username = username;
        this.filePath = new File("D:/users/" + this.username + "/MyDiaryApp/entries.csv").getAbsolutePath();
    }

    public void setCurrentEntry(String entry, String filepath){
        this.currentEntry = entry;
        System.out.println("Selected Entry in CreateController: " + currentEntry);

        try(BufferedReader br = new BufferedReader(new FileReader(filepath))){
            String line, content = "";
            br.readLine();
            while((line = br.readLine())!=null){
                String[] column = line.split(",");
                if(column[0].equals(currentEntry)){
                    titleField.setText(column[0]);
                    datePicker.setValue(convertStringToDate(column[1]));
                    moodSlider.setValue(Double.parseDouble(column[2]));
                    content = column[3].replace("__NEWLINE__", "\n");
                    contentField.setText(content);
                    if (column.length > 4){
                        imagePath.setText(column[4]);
                        displayImage(imagePath.getText());
                    }
                    break;
                }
            }

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    private void displayImage(String imagePath){
        if (imagePath != null && !imagePath.isEmpty()) {
            File file = new File(imagePath);
            if (file.exists()) {
                Image image = new Image(file.toURI().toString());
                ImageView imageView = new ImageView(image);
                imageView.setPreserveRatio(true);
                imageView.setFitWidth(150);

                imageArea.getChildren().clear();
                imageArea.getChildren().add(imageView);
            } else {
                System.out.println("Image file does not exist: " + imagePath);
            }
        } else {
            System.out.println("No image file found");
        }
    }

    @FXML
    void clickToUpload(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File selectedFile = fileChooser.showOpenDialog(imageUpload.getScene().getWindow());

        if (selectedFile != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/system/fop/Image.fxml"));
                AnchorPane imageRoot = loader.load();

                ImageController imageController = loader.getController();
                imageController.setSelectedFile(selectedFile);
                imageController.setEditController(this);

                Stage imageStage = new Stage();
                imageStage.setTitle("Image Upload");
                imageStage.setScene(new Scene(imageRoot));
                imageStage.show();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Error", "Failed to load image upload scene.", Alert.AlertType.ERROR);
            }
        } else {
            System.out.println("No file selected.");
        }
    }

    public void addImageToVBox(File imageFile) {
        Image image = new Image(imageFile.toURI().toString());
        ImageView imageView = new ImageView(image);
        imageView.setPreserveRatio(true);
        imageView.setFitWidth(150);
        imageArea.getChildren().clear();
        imageArea.getChildren().add(imageView);

        String imageMarkdown = imageFile.getAbsolutePath();
        imagePath.setText("");
        imagePath.setText(imageMarkdown);
    }

    @FXML
    void clickToBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/system/fop/Entries.fxml"));
            AnchorPane diaryRoot = loader.load();
            EntriesController entryController = loader.getController();
            entryController.setUsername(username);
            System.out.println("Click Back to entries:  " + username);
            entryController.populate();
            Scene diaryScene = new Scene(diaryRoot);

            Stage stage = (Stage) contentField.getScene().getWindow();
            stage.setScene(diaryScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void clickToSave(ActionEvent event) {
        System.out.println(username + " Save");

        if (titleField.getText().isEmpty() || contentField.getText().isEmpty()) {
            showAlert("Incomplete", "Please fill in the required fields.", Alert.AlertType.ERROR);
            return;
        }

        String title = titleField.getText();
        LocalDate date = (datePicker.getValue() != null) ? datePicker.getValue() : LocalDate.now();
        double mood = moodSlider.getValue();
        String content = contentField.getText();
        String path = imagePath.getText();

        if (filePath == null || filePath.isEmpty()) {
            filePath = new File("D:/users/" + username + "/MyDiaryApp/entries.csv").getAbsolutePath();
            return;
        }

        File file = new File(filePath);
        boolean isModified = false;

        String actualContent = escapeCSV(content);

        if (!file.getParentFile().exists() && !file.getParentFile().mkdirs()) {
            showAlert("Error", "Failed to create directory for the file.", Alert.AlertType.ERROR);
            return;  // Abort further operations
        }

        // Read the entire CSV file into memory
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to read the file.", Alert.AlertType.ERROR);
            return;
        }

        // Find the row to update
        boolean headerProcessed = false;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            String[] columns = line.split(",");

            if (columns.length <= 5 && columns[0].equals(currentEntry)) {
                // Update the row with new values
                lines.set(i, title + "," + date + "," + mood + "," + actualContent + "," + path);
                isModified = true;
                break;
            }
        }

        // If the entry was not found, show an error and return
        if (!isModified) {
            showAlert("Error", "Entry not found to update.", Alert.AlertType.ERROR);
            return;
        }

        // Now write the updated content back to the file
        try (FileWriter writer = new FileWriter(file)) {
            for (String line : lines) {
                writer.write(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to write to the file.", Alert.AlertType.ERROR);
        }

        showAlert("Success", "Diary entry updated successfully!", Alert.AlertType.INFORMATION);

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/system/fop/Entries.fxml"));
            AnchorPane diaryRoot = loader.load();
            EntriesController entriesController = loader.getController();
            entriesController.setUsername(username);
            entriesController.populate();
            Scene diaryScene = new Scene(diaryRoot);
            Stage stage = (Stage) titleField.getScene().getWindow();
            stage.setScene(diaryScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();  // Handle the exception if loading the new scene fails
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private String escapeCSV(String input) {
        input = input.replace("\n", "__NEWLINE__");
        if (input.contains(",") || input.contains("\n") || input.contains("\"")) {
            input = input.replace("\"", "\"\"");
            input = "\"" + input + "\"";
        }
        return input;
    }

    private LocalDate convertStringToDate(String dateString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        try {
            return LocalDate.parse(dateString);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
