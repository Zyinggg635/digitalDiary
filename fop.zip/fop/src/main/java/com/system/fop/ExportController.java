package com.system.fop;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ExportController {
    @FXML
    private DatePicker startDate;
    @FXML
    private ComboBox<String> timeRange;
    @FXML
    private TextField titleSearch;
    @FXML
    private ComboBox<String> moodSelector;
    @FXML
    private Text duration;

    private String username;
    private String filePath;
    private Stage currentStage;

    @FXML
    private void initialize() {
        ObservableList<String> timeRanges = FXCollections.observableArrayList("Daily", "Weekly", "Monthly");
        timeRange.setItems(timeRanges);

        ObservableList<String> moods = FXCollections.observableArrayList("Any", "Very sad", "Sad", "Neutral", "Happy", "Very happy");
        moodSelector.setItems(moods);
        moodSelector.setValue("Any");
    }

    public void setUsername(String username) {
        this.username = username;
        this.filePath = new File("D:/users/" + this.username + "/MyDiaryApp/entries.csv").getAbsolutePath();
    }

    public void setCurrentStage(Stage currentStage) {
        this.currentStage = currentStage;
    }

    @FXML
    public void exportToPdf() {
        String timeRange = this.timeRange.getValue();
        if (timeRange == null) {
            duration.setText("Please select a time range.");
            return;
        }

        LocalDate startDate = this.startDate.getValue();
        if (startDate == null) {
            duration.setText("Please select a start date.");
            return;
        }

        LocalDate endDate = calculateEndDate(startDate, timeRange);
        String titleFilter = titleSearch.getText().trim();
        String moodFilter = moodSelector.getValue();
        List<String[]> filteredEntries = filterEntries(startDate, endDate, titleFilter, moodFilter);
        if (filteredEntries.isEmpty()) {
            duration.setText("No entries found for the selected range.");
            return;
        }

        boolean isSuccess = exportContent(filteredEntries, timeRange, startDate, endDate);
        if (isSuccess && currentStage != null) {
            currentStage.close();
        }
    }

    private LocalDate calculateEndDate(LocalDate startDate, String timeRange) {
        switch (timeRange) {
            case "Daily":
                return startDate;
            case "Weekly":
                return startDate.plusDays(6);
            case "Monthly":
                return startDate.plusMonths(1).minusDays(1);
            default:
                return null;
        }
    }

    private List<String[]> filterEntries(LocalDate startDate, LocalDate endDate, String titleFilter, String moodFilter) {
        List<String[]> filteredEntries = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            br.readLine();
            String line;

            while ((line = br.readLine()) != null) {
                String[] columns = line.split(",", -1);
                if (columns.length >= 5) {
                    LocalDate entryDate = LocalDate.parse(columns[1].trim(), formatter);
                    boolean isValidDate = !entryDate.isBefore(startDate) && !entryDate.isAfter(endDate);
                    boolean isValidTitle = titleFilter.isEmpty() || columns[0].toLowerCase().contains(titleFilter.toLowerCase());
                    String entryMood = getMoodText(columns[2].trim());
                    boolean isValidMood = moodFilter.equals("Any") || entryMood.equals(moodFilter);

                    if (isValidDate && isValidTitle && isValidMood) {
                        filteredEntries.add(columns);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return filteredEntries;
    }

    private String getMoodText(String mood) {
        switch (mood) {
            case "0.0":
                return "Very sad";
            case "1.0":
                return "Sad";
            case "2.0":
                return "Neutral";
            case "3.0":
                return "Happy";
            case "4.0":
                return "Very happy";
            default:
                return "";
        }
    }

    private boolean exportContent(List<String[]> entries, String timeRange, LocalDate startDate, LocalDate endDate) {
        File outputDir = new File("D:/users/" + username + "/MyDiaryApp");
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            duration.setText("Failed to create output directory.");
            return false;
        }

        File outputFile;
        try {
            String base = "/Diary";
            String fileExtension = ".pdf";
            int counter = 1;
            do {
                outputFile = new File(outputDir, (base + counter + fileExtension));
                counter++;
            } while (outputFile.exists());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        try (PdfWriter writer = new PdfWriter(new FileOutputStream(outputFile))) {
            PdfDocument pdfDoc = new PdfDocument(writer);
            Document document = new Document(pdfDoc);

            document.add(new Paragraph(timeRange + " Diary Entries"));
            document.add(new Paragraph("From " + startDate + " to " + endDate));
            document.add(new Paragraph(" "));

            for (String[] entry : entries) {
                String title = entry[0].trim();
                String date = entry[1].trim();
                String mood = getMoodText(entry[2].trim());
                String content = entry[3].trim().replace("__NEWLINE__", "\n");

                document.add(new Paragraph("Title    : " + title));
                document.add(new Paragraph("Date   : " + date));
                document.add(new Paragraph("Mood    : " + mood));
                document.add(new Paragraph("Content: \n" + content));
                document.add(new Paragraph(" "));
            }

            document.close();
            System.out.println("PDF exported successfully: " + outputFile.getAbsolutePath());
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            duration.setText("Error exporting PDF.");
            return false;
        }
    }
}
