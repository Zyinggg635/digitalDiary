package com.system.fop;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import java.io.File;

public class ImageController {
    @FXML
    private Button confirmButton;

    @FXML
    private ImageView imageView;

    private File selectedFile;
    private CreateController createController;
    private EditController editController;

    public void setSelectedFile(File selectedFile) {
        this.selectedFile = selectedFile;
        loadImage();
    }

    public void setCreateController(CreateController createController) {
        this.createController = createController;
    }

    public void setEditController(EditController editController) {
        this.editController = editController;
    }

    public void loadImage() {
        if (selectedFile != null) {
            try {
                Image image = new Image(selectedFile.toURI().toString());
                imageView.setImage(image);
            } catch (Exception e) {
                System.err.println("Error loading image: " + e.getMessage());
            }
        }else{
            System.err.println("No image selected");
        }
    }

    @FXML
    private void onConfirmButtonClick(){
        Stage stage = (Stage) confirmButton.getScene().getWindow();
        stage.close();
        System.out.println("Image uploaded");
        if (createController != null) {
            createController.addImageToVBox(selectedFile);
        }

        if (editController != null) {
            editController.addImageToVBox(selectedFile);
        }
    }
}
